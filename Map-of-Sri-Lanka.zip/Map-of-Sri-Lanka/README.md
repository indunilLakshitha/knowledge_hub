# Map-of-Sri-Lanka
A customizable interactive map of Sri Lanka
JavaScript-based maps are zoomable, clickable, responsive, and easy to customize. Easily add locations, like Colombo (shown above) to your maps. 
